# LaorORG © Netfix

LaorORG © Netfix (Copyright © 2026 LaorORG) is a Chrome/Edge (Manifest V3) browser extension that **automatically injects a hardcoded Netflix cookie** every time you click the extension icon.

## Behavior (on every popup open)

1. **Clears** all existing cookies for `netflix.com`
2. **Injects** the saved `nfvdid` cookie
3. **Refreshes** every open Netflix tab

No paste box or manual buttons — it runs the moment the popup appears.

## Installation (Developer Mode)

1. Open Chrome / Edge → `chrome://extensions` (or `edge://extensions`)
2. Enable **Developer mode**
3. Click **Load unpacked**
4. Select the LaorORG © Netfix extension folder
5. Click the extension icon whenever you want to apply the cookie

## Hardcoded Cookie

The cookie is stored in `popup.js` inside the `SAVED_COOKIES` array.  
To change it later, simply replace the object(s) in that array and reload the extension.

## Permissions

- `cookies` – read / write / delete Netflix cookies  
- `tabs` – find & reload Netflix tabs  
- Host permissions limited to `*.netflix.com`

## Notes

- Intended for personal session recovery / testing.  
- Using unauthorized account cookies may violate Netflix Terms of Service.  
- Keep your cookies private.

## License

MIT
